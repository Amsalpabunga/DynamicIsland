package dev.android.dynamicisland.settings;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.text.LineBreakConfig;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import dev.android.dynamicisland.R;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Builds the One UI look of the settings screen: grouped rounded cards on a tinted page, titles with their
 * value or summary underneath, accent-coloured group labels. The row types are the setting kinds the screen
 * uses: {@link #switchRow} (on / off), {@link #valueRow} (opens a choice, shows the current value),
 * {@link #linkRow} (opens a sub page) and {@link #actionRow} (does something). Main thread only.
 */
final class OneUi {
    final int background;
    final int cardColor;
    final int textColor;
    final int muted;
    final int accent;
    final int divider;
    final int good;
    final int warn;
    final boolean dark;

    private final Context ctx;
    private final float density;
    private Runnable searchAction;

    void setSearchAction(Runnable action) { searchAction=action; }

    OneUi(Context ctx) {
        this.ctx = ctx;
        density = ctx.getResources().getDisplayMetrics().density;
        dark = (ctx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        background = dark ? 0xff000000 : 0xfff3f3f6;
        cardColor = dark ? 0xff171719 : 0xffffffff;
        textColor = dark ? 0xfffafafa : 0xff111114;
        muted = dark ? 0xff9a9aa2 : 0xff75757d;
        accent = dark ? 0xff5ea3ff : 0xff0a6cff;
        divider = dark ? 0xff26262a : 0xffececf0;
        good = dark ? 0xff4fd18b : 0xff1a9e5a;
        warn = dark ? 0xffffb44f : 0xffd97a00;
    }

    int dp(int v) {
        return Math.round(v * density);
    }

    TextView text(CharSequence value, int sp, int color) {
        TextView v = new TextView(ctx);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        // break Korean at phrase boundaries instead of in the middle of a word
        v.setLineBreakWordStyle(LineBreakConfig.LINE_BREAK_WORD_STYLE_PHRASE);
        return v;
    }

    GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private RippleDrawable ripple() {
        return new RippleDrawable(ColorStateList.valueOf(0x1f808080), null, round(Color.WHITE, 0));
    }

    /** Big centred title with an optional line under it; {@code top} is the space above in dp. */
    void title(LinearLayout page, CharSequence title, CharSequence tagline, int top) {
        TextView t = text(title, 28, textColor);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(top), 0, dp(6));
        page.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text(tagline == null ? "" : tagline, 14, muted);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(dp(24), 0, dp(24), dp(tagline == null ? 12 : 32));
        if (tagline == null) {
            sub.setVisibility(View.GONE);
        }
        page.addView(sub, new LinearLayout.LayoutParams(-1, -2));
    }

    void pageHeader(LinearLayout page, CharSequence title, Runnable back) {
        LinearLayout bar = new LinearLayout(ctx);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, dp(10), dp(8), dp(12));
        TextView arrow = text("‹", 34, textColor);
        arrow.setGravity(Gravity.CENTER);
        arrow.setContentDescription(ctx.getString(R.string.back));
        arrow.setBackground(ripple());
        arrow.setOnClickListener(v -> back.run());
        bar.addView(arrow, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView name = text(title, 23, textColor);
        name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        name.setPadding(dp(8), 0, 0, 0);
        bar.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        if(searchAction!=null&&!title.toString().equals(ctx.getString(R.string.search_title))) {
            android.widget.ImageView search=new android.widget.ImageView(ctx);
            search.setImageResource(android.R.drawable.ic_menu_search);search.setImageTintList(ColorStateList.valueOf(textColor));
            search.setPadding(dp(12),dp(12),dp(12),dp(12));search.setBackground(ripple());search.setFocusable(true);
            search.setContentDescription(ctx.getString(R.string.search_title));search.setOnClickListener(v->searchAction.run());
            bar.addView(search,new LinearLayout.LayoutParams(dp(48),dp(48)));
        }
        page.addView(bar, new LinearLayout.LayoutParams(-1, -2));
    }

    void details(LinearLayout page, CharSequence title, CharSequence description) {
        LinearLayout card = card(page);
        linkRow(card, title, title.equals(ctx.getString(R.string.ui_details)) ? null : ctx.getString(R.string.ui_details), () ->
                new android.app.AlertDialog.Builder(ctx).setTitle(title).setMessage(description)
                        .setPositiveButton(android.R.string.ok, null).show());
    }

    /** The round back button of sub pages. */
    TextView backButton(LinearLayout page, CharSequence description, Runnable onBack) {
        TextView back = text("‹", 34, textColor);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription(description);
        back.setBackground(ripple());
        back.setOnClickListener(v -> onBack.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(48), dp(48));
        p.topMargin = dp(8);
        page.addView(back, p);
        return back;
    }

    /** Status card: a coloured dot, a headline and a detail line. Returns the card; see {@link #setHero}. */
    LinearLayout hero(LinearLayout page) {
        LinearLayout card = card(page);
        card.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout line = new LinearLayout(ctx);
        line.setGravity(Gravity.CENTER_VERTICAL);
        View dot = new View(ctx);
        dot.setBackground(round(muted, dp(6)));
        line.addView(dot, new LinearLayout.LayoutParams(dp(10), dp(10)));
        TextView status = text("", 18, textColor);
        status.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        status.setPadding(dp(10), 0, 0, 0);
        line.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(line);
        TextView detail = text("", 13, muted);
        detail.setPadding(dp(20), dp(6), 0, 0);
        card.addView(detail);
        return card;
    }

    void setHero(LinearLayout hero, boolean ok, CharSequence status, CharSequence detail) {
        LinearLayout line = (LinearLayout) hero.getChildAt(0);
        line.getChildAt(0).setBackground(round(ok ? good : warn, dp(6)));
        ((TextView) line.getChildAt(1)).setText(status);
        ((TextView) hero.getChildAt(1)).setText(detail);
    }

    /** Accent-coloured label above a card. */
    void category(LinearLayout page, CharSequence title) {
        TextView label = text(title, 14, accent);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        label.setPadding(dp(22), dp(26), 0, dp(2));
        page.addView(label);
    }

    /** A section label with a small line below it saying what the section is. */
    void category(LinearLayout page, CharSequence title, CharSequence description) {
        category(page, title);
        if (description == null || description.length() == 0) return;
        TextView sub = text(description, 13, muted);
        sub.setPadding(dp(22), dp(2), dp(22), 0);
        page.addView(sub);
    }

    LinearLayout card(LinearLayout page) {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(round(cardColor, dp(26)));
        c.setClipToOutline(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(10);
        page.addView(c, p);
        return c;
    }

    void searchEntry(LinearLayout page,Runnable open) {
        LinearLayout bar=card(page);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setMinimumHeight(dp(56));bar.setPadding(dp(20),0,dp(20),0);
        android.widget.ImageView icon=new android.widget.ImageView(ctx);
        icon.setImageResource(android.R.drawable.ic_menu_search);icon.setImageTintList(ColorStateList.valueOf(muted));
        bar.addView(icon,new LinearLayout.LayoutParams(dp(24),dp(24)));
        TextView label=text(ctx.getString(R.string.search_title),17,muted);label.setPadding(dp(12),0,0,0);bar.addView(label);
        bar.setForeground(ripple());bar.setFocusable(true);bar.setContentDescription(ctx.getString(R.string.search_title));
        bar.setOnClickListener(v->open.run());
    }

    void note(LinearLayout page, CharSequence content) {
        TextView t = text(content, 13, muted);
        t.setLineSpacing(dp(2), 1f);
        t.setPadding(dp(22), dp(10), dp(22), 0);
        page.addView(t);
    }

    private void separator(LinearLayout group) {
        if (group.getChildCount() == 0) {
            return;
        }
        View line = new View(ctx);
        line.setBackgroundColor(divider);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Math.max(1, dp(1) / 2));
        p.leftMargin = dp(22);
        p.rightMargin = dp(22);
        group.addView(line, p);
    }

    /** A row with a title and a summary, optionally clickable; returns its container. */
    private LinearLayout box(LinearLayout group, CharSequence title, CharSequence summary, int summaryColor, Runnable action, boolean chevron) {
        separator(group);
        LinearLayout box = new LinearLayout(ctx);
        box.setTag(title.toString());
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(22), dp(14), dp(16), dp(14));
        box.setMinimumHeight(dp(64));
        LinearLayout words = new LinearLayout(ctx);
        words.setOrientation(LinearLayout.VERTICAL);
        words.addView(text(title, 17, textColor));
        TextView detail = text(summary == null ? "" : summary, 14, summaryColor);
        detail.setPadding(0, dp(2), dp(8), 0);
        detail.setMaxLines(2);
        detail.setEllipsize(TextUtils.TruncateAt.END);
        if (summary == null || summary.length() == 0) {
            detail.setVisibility(View.GONE);
        }
        words.addView(detail);
        box.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        if (chevron) {
            TextView arrow = text("›", 26, muted);
            box.addView(arrow);
        }
        if (action != null) {
            box.setBackground(ripple());
            box.setOnClickListener(v -> action.run());
        }
        group.addView(box, new LinearLayout.LayoutParams(-1, -2));
        return box;
    }

    /** On / off setting; the summary explains it. {@code onChange} gets the new state. */
    Switch switchRow(LinearLayout group, CharSequence title, CharSequence summary, boolean checked, Consumer<Boolean> onChange) {
        LinearLayout box = box(group, title, summary, muted, null, false);
        Switch sw = new GalaxySwitch(ctx);
        sw.setMinHeight(dp(48));
        sw.setMinWidth(dp(48));
        sw.setContentDescription(title);
        sw.setChecked(checked);
        box.addView(sw);
        box.setBackground(ripple());
        List<Consumer<Boolean>> listeners = new ArrayList<>();
        listeners.add(onChange);
        sw.setTag(listeners);
        sw.setOnCheckedChangeListener((button, on) -> {
            for (Consumer<Boolean> listener : listeners) listener.accept(on);
        });
        box.setOnClickListener(v -> sw.toggle());
        return sw;
    }

    /** Also calls {@code listener} when the user flips the switch of a {@link #switchRow}. */
    @SuppressWarnings("unchecked")
    static void listen(Switch sw, Consumer<Boolean> listener) {
        ((List<Consumer<Boolean>>) sw.getTag()).add(listener);
    }

    /**
     * A row that opens a sub page when tapped and has its own switch at the end (a rule that can be switched off
     * and also looked into). Returns the switch.
     */
    Switch ruleRow(LinearLayout group, CharSequence title, CharSequence summary, boolean checked,
            Consumer<Boolean> onChange, Runnable open) {
        LinearLayout box = box(group, title, summary, muted, open, false);
        View divider = new View(ctx);
        divider.setBackgroundColor(this.divider);
        LinearLayout.LayoutParams line = new LinearLayout.LayoutParams(Math.max(1, dp(1) / 2), dp(32));
        line.leftMargin = dp(4);
        line.rightMargin = dp(12);
        box.addView(divider, line);
        Switch sw = new GalaxySwitch(ctx);
        sw.setMinHeight(dp(48));
        sw.setMinWidth(dp(48));
        sw.setContentDescription(title);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener((button, on) -> onChange.accept(on));
        box.addView(sw);
        return sw;
    }

    /** A text field laid out like the other rows: a small label above, the typed text in the row's title size. */
    EditText inputRow(LinearLayout group, CharSequence label, CharSequence hint, boolean multiline, boolean monospace) {
        separator(group);
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(14), dp(22), dp(14));
        box.setMinimumHeight(dp(64));
        TextView caption = text(label, 14, accent);
        box.addView(caption);
        EditText edit = new EditText(ctx);
        edit.setBackground(null);
        edit.setPadding(0, dp(4), 0, 0);
        edit.setTextSize(17);
        edit.setTextColor(textColor);
        edit.setHintTextColor(muted);
        edit.setHint(hint);
        edit.setSingleLine(!multiline);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (multiline ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        if (multiline) {
            edit.setMinLines(2);
            edit.setGravity(Gravity.TOP);
        }
        if (monospace) {
            edit.setTypeface(Typeface.MONOSPACE);
        }
        box.addView(edit, new LinearLayout.LayoutParams(-1, -2));
        group.addView(box, new LinearLayout.LayoutParams(-1, -2));
        return edit;
    }

    /** Removes every row of a card, to fill it again. */
    static void clear(LinearLayout group) {
        group.removeAllViews();
    }

    /** The row view that holds the given switch (to dim it together with its dependants). */
    static View rowOf(Switch sw) {
        return (View) sw.getParent();
    }

    /** Setting with a choice behind it: the current value is shown under the title in the accent colour. */
    TextView valueRow(LinearLayout group, CharSequence title, CharSequence value, Runnable open) {
        LinearLayout box = box(group, title, value, accent, open, false);
        return (TextView) ((LinearLayout) box.getChildAt(0)).getChildAt(1);
    }

    /**
     * A One UI radio list: a small accent label, then a card with one row per option and a radio dot at the end.
     * Tapping a row selects it at once, with no dialog in between, so the preview above can show the result.
     * The card carries the tag the search jumps to.
     */
    static final int TAG_DEFAULT = 1, TAG_RECOMMENDED = 2;

    LinearLayout radioGroup(LinearLayout page, CharSequence title, CharSequence description, CharSequence[] labels, int[] tags, int selected, java.util.function.IntConsumer onSelect) {
        category(page, title, description);
        LinearLayout card = card(page);
        card.setTag(title.toString());
        RadioDot[] dots = new RadioDot[labels.length];
        for (int i = 0; i < labels.length; i++) {
            separator(card);
            LinearLayout row = new LinearLayout(ctx);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(22), dp(10), dp(16), dp(10));
            row.setMinimumHeight(dp(56));
            row.setBackground(ripple());
            LinearLayout line = new LinearLayout(ctx);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.addView(text(labels[i], 17, textColor));
            int flags = tags == null ? 0 : tags[i];
            if ((flags & TAG_DEFAULT) != 0) line.addView(tagPill(ctx.getString(R.string.ui_default), accent));
            if ((flags & TAG_RECOMMENDED) != 0) line.addView(tagPill(ctx.getString(R.string.tag_recommended), good));
            row.addView(line, new LinearLayout.LayoutParams(0, -2, 1));
            RadioDot dot = new RadioDot(ctx, i == selected);
            dots[i] = dot;
            row.addView(dot, new LinearLayout.LayoutParams(dp(24), dp(24)));
            row.setSelected(i == selected);
            row.setContentDescription(labels[i]);
            final int index = i;
            row.setOnClickListener(v -> {
                for (int k = 0; k < dots.length; k++) dots[k].set(k == index);
                onSelect.accept(index);
            });
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        return card;
    }

    /** A small rounded label next to an option ("Default", "Recommended"), tinted with {@code colour}. */
    private TextView tagPill(CharSequence label, int colour) {
        TextView pill = text(label, 12, colour);
        pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        pill.setPadding(dp(8), dp(2), dp(8), dp(2));
        GradientDrawable bg = round(colour, dp(8));
        bg.setAlpha(36);
        pill.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(10);
        pill.setLayoutParams(p);
        return pill;
    }

    /** The round selection mark of a radio row: an outline, or the accent colour with a tick when chosen. */
    private final class RadioDot extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private boolean on;
        RadioDot(Context context, boolean on) { super(context); this.on = on; setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO); }
        void set(boolean value) { on = value; invalidate(); }
        @Override protected void onDraw(android.graphics.Canvas c) {
            float r = getWidth() / 2f - dp(2);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            if (on) {
                paint.setStyle(android.graphics.Paint.Style.FILL);
                paint.setColor(accent);
                c.drawCircle(cx, cy, r + dp(1), paint);
                paint.setStyle(android.graphics.Paint.Style.STROKE);
                paint.setColor(0xffffffff);
                paint.setStrokeWidth(dp(2));
                paint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                paint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
                android.graphics.Path tick = new android.graphics.Path();
                tick.moveTo(cx - r * 0.42f, cy + r * 0.02f);
                tick.lineTo(cx - r * 0.08f, cy + r * 0.38f);
                tick.lineTo(cx + r * 0.5f, cy - r * 0.32f);
                c.drawPath(tick, paint);
            } else {
                paint.setStyle(android.graphics.Paint.Style.STROKE);
                paint.setColor(dark ? 0xff6a6a72 : 0xffb4b4bc);
                paint.setStrokeWidth(dp(2));
                c.drawCircle(cx, cy, r, paint);
            }
        }
    }

    /** Entry to a sub page. */
    TextView linkRow(LinearLayout group, CharSequence title, CharSequence summary, Runnable open) {
        LinearLayout box = box(group, title, summary, muted, open, true);
        return (TextView) ((LinearLayout) box.getChildAt(0)).getChildAt(1);
    }

    /** Button-like row that performs something. */
    TextView actionRow(LinearLayout group, CharSequence title, CharSequence summary, Runnable run) {
        LinearLayout box = box(group, title, summary, muted, run, false);
        return (TextView) ((LinearLayout) box.getChildAt(0)).getChildAt(1);
    }

    /** Dims a group of views and blocks taps while the setting they depend on is off. */
    static void setDependentsEnabled(boolean on, View... views) {
        for (View v : views) {
            v.setAlpha(on ? 1f : 0.4f);
            setEnabledDeep(v, on);
        }
    }

    private static void setEnabledDeep(View v, boolean on) {
        v.setEnabled(on);
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                setEnabledDeep(g.getChildAt(i), on);
            }
        }
    }
}
