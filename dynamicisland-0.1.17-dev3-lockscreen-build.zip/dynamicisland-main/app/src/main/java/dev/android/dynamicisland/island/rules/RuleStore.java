package dev.android.dynamicisland.island.rules;

import dev.android.dynamicisland.settings.ModuleSettings;
import dev.android.dynamicisland.xposed.XLog;
import dev.android.dynamicisland.island.EmbeddedResources;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * The rules in force: the module's own rule file and the user's own file, merged. Rebuilt only when the
 * settings changed; any thread.
 */
public final class RuleStore {
    /** The module's own rule file, always in force. */
    private static final String[] BUILTIN = {
            "/dev/android/dynamicisland/rules/builtin-ko.json", "/dev/android/dynamicisland/rules/builtin-en.json",
            "/dev/android/dynamicisland/rules/builtin-translations.json"};
    private static final Object LOCK = new Object();
    private static volatile RuleDictionary current = RuleDictionary.empty();
    private static volatile long builtFor;
    private static volatile boolean built;
    private static volatile RuleDictionary forTesting;

    private RuleStore() {
    }

    /** The merged rules for the current settings. Never null; empty when nothing could be loaded. */
    public static RuleDictionary current() {
        RuleDictionary pinned = forTesting;
        if (pinned != null) {
            return pinned;
        }
        RuleConfig config = ModuleSettings.rulesConfig();
        if (!built || builtFor != config.revision) {
            synchronized (LOCK) {
                if (!built || builtFor != config.revision) {
                    current = build(config);
                    builtFor = config.revision;
                    built = true;
                }
            }
        }
        return current;
    }

    /** Builds the merged rules for {@code config}. A file that does not parse is skipped. */
    public static RuleDictionary build(RuleConfig config) {
        RuleDictionary merged = RuleDictionary.empty();
        // Korean and English detection rules, then generated display labels; custom rules still go last.
        for (String path : BUILTIN) {
            RuleDictionary builtin = RuleDictionary.fromJson(readResource(path));
            if (builtin != null) {
                merged = merged.mergedWith(builtin);
            } else {
                XLog.i("rule file " + path + " could not be loaded");
            }
        }
        RuleDictionary custom = RuleDictionary.fromJson(config.custom);
        // Keep existing user English edits above newly supplied language defaults.
        RuleDictionary fallback = custom == null ? null : translatedCustomFallback(config.custom);
        if (fallback != null) {
            merged = merged.mergedWith(fallback);
        }
        return (custom == null ? merged : merged.mergedWith(custom)).without(config.disabled);
    }

    private static RuleDictionary translatedCustomFallback(String raw) {
        try {
            JSONObject labels = new JSONObject(raw).optJSONObject("status_labels");
            if (labels == null) {
                return null;
            }
            JSONObject fallback = new JSONObject();
            java.util.Iterator<String> ids = labels.keys();
            while (ids.hasNext()) {
                String id = ids.next();
                JSONObject languages = labels.optJSONObject(id);
                JSONObject english = languages == null ? null : languages.optJSONObject("en");
                if (english != null) {
                    JSONObject defaults = new JSONObject();
                    for (String language : dev.android.dynamicisland.island.IslandText.languages()) {
                        if (!language.equals("en") && !language.equals("ko")) defaults.put(language, english);
                    }
                    fallback.put(id, defaults);
                }
            }
            return RuleDictionary.fromJson(new JSONObject().put("status_labels", fallback).toString());
        } catch (JSONException e) {
            return null;
        }
    }

    private static String readResource(String path) {
        return EmbeddedResources.get(path);
    }

    /** Makes {@link #current()} return {@code dictionary} (null undoes it); for tests. */
    public static void setForTesting(RuleDictionary dictionary) {
        forTesting = dictionary;
    }

    /** Forgets the cached rules (tests). */
    static void reset() {
        synchronized (LOCK) {
            built = false;
            current = RuleDictionary.empty();
        }
    }
}
